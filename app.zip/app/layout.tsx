import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Internet Clock - World Time & Weather",
  description: "Beautiful world clock with multiple themes, weather information, and productivity tools",
  keywords: ["clock", "time", "weather", "world clock", "timer", "stopwatch"],
  authors: [{ name: "Internet Clock" }],
  viewport: "width=device-width, initial-scale=1",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  )
}