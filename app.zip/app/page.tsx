"use client"

import React, { useState, useEffect } from 'react'
import ClockComponent from '@/components/ClockComponent'
import WeatherComponent from '@/components/WeatherComponent'
import AdManager from '@/components/AdManager'
import InterstitialAd from '@/components/InterstitialAd'
import BannerAd from '@/components/BannerAd'
import RewardedVideoAd from '@/components/RewardedVideoAd'

export default function HomePage() {
  const [currentView, setCurrentView] = useState('clock')
  const [clickCount, setClickCount] = useState(0)
  const [showInterstitial, setShowInterstitial] = useState(false)
  const [theme, setTheme] = useState('cosmic')
  const [userLocation, setUserLocation] = useState<{lat: number, lon: number} | null>(null)

  // Ad configuration
  const adConfig = {
    interstitialFrequency: 7, // Show interstitial every 7 clicks
    bannerRefreshRate: 30000, // Refresh banner every 30 seconds
    rewardedVideoAvailable: true
  }

  // Handle clicks and ad triggers
  const handleUserClick = () => {
    const newClickCount = clickCount + 1
    setClickCount(newClickCount)

    // Show interstitial ad every X clicks
    if (newClickCount % adConfig.interstitialFrequency === 0) {
      setShowInterstitial(true)
    }
  }

  // Get user location for weather
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude
          })
        },
        (error) => {
          console.log('Location access denied, using default location')
          setUserLocation({ lat: 40.7128, lon: -74.0060 }) // Default to NYC
        }
      )
    }
  }, [])

  const views = [
    { id: 'clock', name: '🕐 Clock', component: ClockComponent },
    { id: 'weather', name: '🌤️ Weather', component: WeatherComponent },
    { id: 'timer', name: '⏲️ Timer', component: ClockComponent },
    { id: 'stopwatch', name: '⏱️ Stopwatch', component: ClockComponent },
    { id: 'worldclock', name: '🌍 World', component: ClockComponent },
    { id: 'focus', name: '🎯 Focus', component: ClockComponent }
  ]

  const getCurrentComponent = () => {
    const view = views.find(v => v.id === currentView)
    if (!view) return null
    
    const Component = view.component
    
    if (currentView === 'weather') {
      return <Component userLocation={userLocation} theme={theme} />
    } else {
      return <Component 
        theme={theme} 
        setTheme={setTheme} 
        mode={currentView}
        onUserClick={handleUserClick}
      />
    }
  }

  return (
    <div className={`app ${theme}`}>
      {/* Navigation */}
      <div className="nav-container">
        {views.map(view => (
          <button
            key={view.id}
            className={`nav-btn ${currentView === view.id ? 'active' : ''}`}
            onClick={() => {
              setCurrentView(view.id)
              handleUserClick()
            }}
          >
            {view.name}
          </button>
        ))}
      </div>

      {/* Side Ads */}
      <div className="side-ads">
        <BannerAd 
          position="left" 
          size="160x600"
          refreshRate={adConfig.bannerRefreshRate}
        />
        <BannerAd 
          position="right" 
          size="160x600"
          refreshRate={adConfig.bannerRefreshRate}
        />
      </div>

      {/* Main Content */}
      <div className="main-content">
        {getCurrentComponent()}
      </div>

      {/* Bottom Banner Ad */}
      <BannerAd 
        position="bottom" 
        size="728x90"
        refreshRate={adConfig.bannerRefreshRate}
      />

      {/* Interstitial Ad */}
      {showInterstitial && (
        <InterstitialAd 
          onClose={() => setShowInterstitial(false)}
          onUserClick={handleUserClick}
        />
      )}

      {/* Ad Manager */}
      <AdManager 
        clickCount={clickCount}
        adConfig={adConfig}
        onShowInterstitial={() => setShowInterstitial(true)}
      />

      {/* Rewarded Video Ad */}
      {adConfig.rewardedVideoAvailable && (
        <RewardedVideoAd 
          onRewardEarned={() => console.log('Reward earned!')}
          onUserClick={handleUserClick}
        />
      )}
    </div>
  )
}